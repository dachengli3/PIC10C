#ifndef ENEMY_H
#define ENEMY_H

#include <QGraphicsRectItem>
#include <QObject>
#include <QGraphicsItem>


class enemy: public QObject, public QGraphicsRectItem{
    Q_OBJECT
public:
    enemy(QGraphicsItem *parent = nullptr);
    void setMovementSpeed(int speed);
    void changeLevel(int level);
public slots:
    void move();

private:
    int enemyType;
    int moveSpeed=5;
    int level;
};


#endif // ENEMY_H

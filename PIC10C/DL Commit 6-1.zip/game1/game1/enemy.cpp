#include "enemy.h"
#include "game.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QList>
#include <stdlib.h> //this gives us the random function

extern Game * game;

//constructor
enemy::enemy(QGraphicsItem *parent): QObject(), QGraphicsRectItem(parent){
    //setting random positions of enemy
    int random_number = rand() % 700;
    enemyType=rand() % level + 1;
    setPos(random_number, 0);

    //size of enemy
    if(level==1)
    {
        setRect(0,0,100,100);
    }
    if(level==2)
    {
        setRect(0,0,100,100);
        setRotation(45);
    }
    if(level==3)
    {

    }


    //connect some stuff
    QTimer *timer = new QTimer();
    connect(timer, SIGNAL(timeout()), this, SLOT(move()));

    //for every 50 milliseconds bullet will move
    timer->start(50);
}

void enemy::setMovementSpeed(int speed)
{
    moveSpeed=speed;
}

void enemy::changeLevel(int newLevel)
{
    if(newLevel>=4)
        return;
    level=newLevel;
}

void enemy::move(){
    //movement of enemy
    setPos(x(),y()+moveSpeed);

    //destroy enemy when it goes out of screen
    if (pos().y() > 600){
        //decreasing health
        game->health->decrease();

        //cleaning up the bullet memory when it reaches the top of window
        scene()->removeItem(this);
        delete this;
    }

}

#ifndef GAME_H
#define GAME_H

#include <QGraphicsScene>
#include <QGraphicsView>
#include <QWidget>
#include <QFont>
#include "rectangle.h" //player
#include "score.h"
#include "health.h"

class Game: public QGraphicsView{
public:
    Game(QWidget *parent = nullptr);

    QGraphicsScene *scene;
    Player *player;
    Score *score;
    Health *health;

public slots:
    void start();
};

#endif // GAME_H

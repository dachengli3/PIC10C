#ifndef RECTANGLE_H
#define RECTANGLE_H
#include <QGraphicsRectItem>
#include <QObject>
#include <QGraphicsItem>
#include "enemy.h"
#include <vector>
#include <QPixmap>

class Player: public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Player(QGraphicsItem *parent = nullptr);
    void keyPressEvent(QKeyEvent *event);
    std::vector<enemy> currentStore;
    void stored();
public slots:
    void spawn();

private:
    QPixmap *enemy1;
    QPixmap *enemy2;
    QPixmap *enemy3;
};

#endif // RECTANGLE_H

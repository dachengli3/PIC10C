#include "rectangle.h"
#include "bullet.h"
#include "enemy.h"
#include <QKeyEvent>
#include <QGraphicsScene>
//#include <QDebug>

Player::Player(QGraphicsItem *parent): QGraphicsPixmapItem(parent){
    //setPixmap()
//    *enemy1=new QPixmap();
//    *enemy2=new QPixmap();
//    *enemy3=new QPixmap();
}

void Player::keyPressEvent(QKeyEvent *event){
    //for debugging purposes
    //qDebug() << "rectangle class knows that you pressed a key";

    //using arrow keys to control player`s movement
    //can ONLY go left or right
    if (event->key() == Qt::Key_Left){
        //checking to see if it has hit the left wall yet
        if (pos().x() > 0){
            setPos(x()-10,y());
        }
    }
    else if (event->key() == Qt::Key_Right){
        //checking to see if it has hit the right wall yet
        //800 is the width of the window
        if (pos().x()+100 < 800){
            setPos(x()+10, y());
        }
    }

//    //spacebar is used to shoot at enemy
//    else if (event->key() == Qt::Key_Space) {
//        //creating bullet
//        //creating bullet pointer
//        bullet *b = new bullet();
//        //qDebug() << "bullet created";
//        b->setPos(x(),y());
//        scene()->addItem(b);
//    }


    //collecting the objects

}

void Player::spawn(){
    //create an enemy
    enemy *e = new enemy;
    scene()->addItem(e);
}

